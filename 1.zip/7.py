with open('ingredient4 (1).txt', 'r', encoding="utf-8") as file:
    for line in file:
        # 줄을 '$' 기준으로 나누기
        parts = line.strip().split('$')
        # 오른쪽 값이 존재하면 오른쪽 값을 사용하고, 그렇지 않으면 왼쪽 값을 사용
        ingredient_name = parts[-1].strip()
        print(ingredient_name)