import requests
import re
def get_ingredients(start, last):
    with open("ingredients.txt", "w", encoding="utf-8") as file:
        URL = f"http://openapi.foodsafetykorea.go.kr/api/2055492edca74694aa38/COOKRCP01/json/{start}/{last}"
        response = requests.get(URL)
        data = response.json()
        arr = set()
        
        for item in data['COOKRCP01']['row']:
            recipe = item.get('RCP_PARTS_DTLS')
            food_name = item.get('RCP_NM')
            
            if food_name in recipe:
                recipe = recipe.replace(food_name,'')
            ingredients_list = recipe.split(',')
            for ingredient in ingredients_list:
                # 정규표현식을 사용하여 숫자와 숫자 뒤에 붙은 문자열을 제거
                ingredient_name = re.sub(r'\d+(\S+)', '', ingredient)
                ingredient_name = ingredient_name.strip()  # 좌우 공백 제거
                if '●' in ingredient_name:
                    ingredient_name = ingredient_name.replace('●', '')
                if ':' in ingredient_name:
                    ingredient_name = ingredient_name.replace(':', '')
                if '약간' in ingredient_name:
                    ingredient_name = ingredient_name.replace('약간', '')
                if '(' in ingredient_name:
                    ingredient_name = ingredient_name.replace('(', '')
                if '재료 ' in ingredient_name:
                    ingredient_name = ingredient_name.replace('재료 ', '')
                
                # 파일에 재료 쓰기
                # if ingredient_name.strip() not in arr:

                #     arr.add(ingredient_name.strip())
                arr.add(ingredient_name)
        for i in arr:
            if '다진 마늘' in i:
                print(i)
        arr= list(arr)
        arr.sort()
        for i in arr:

            file.write(i + "\n")
get_ingredients(1,1001)
