from konlpy.tag import Kkma
kkma = Kkma()
import re
import requests
import json



# def get_url(start, last):
 
#     URL = f"http://openapi.foodsafetykorea.go.kr/api/2055492edca74694aa38/COOKRCP01/json/{start}/{last}"
#     response = requests.get(URL)
#     data = response.json()

#     for item in data['COOKRCP01']['row']:
#         food_recipe = {}
#         for key, value in item.items():
#                 food_recipe[key] = value  # MANUAL로 시작하는 모든 키의 값을 합침
        

#         print(food_recipe)
            
# get_url(1, 2)
def get_ingredients(start, last):
    URL = f"http://openapi.foodsafetykorea.go.kr/api/2055492edca74694aa38/COOKRCP01/json/{start}/{last}"
    response = requests.get(URL)
    data = response.json()
    lst=[]
    ol = []
    for item in data['COOKRCP01']['row']:
        recipe = item.get('RCP_PARTS_DTLS')
        # print(recipe,112)
        food_name = item.get('RCP_NM')
        

        recipe = kkma.pos(recipe)
        for i in recipe:
            if i[1] == 'OL' and i[0] != 'g' and i not in ol:
                ol.append(i)
                
        lst.append(recipe)
        # for line in recipe:
        #     ingredient = line.strip()
        #     if ingredient:  # 빈 줄이 아닌 경우에만 추가
        #         ingredient = kkma.pos(ingredient)
        #         # print(ingredient)
        #     temp=''
            
        #     for i in ingredient:
                
        #         if i[0] not in lst:

        #             temp+=str(i)
        # lst.append(temp)
    with open('ingredient6.txt', 'w', encoding="utf-8") as file:
        for ingredient in lst:
            file.write(str(ingredient) + '\n')
    with open('ingredient7.txt', 'w', encoding="utf-8") as file:
        for ingredient in ol:
            file.write(str(ingredient) + '\n')

get_ingredients(1,1000)