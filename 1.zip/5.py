from konlpy.tag import Kkma
kkma = Kkma()
text = '편 마늘'
print(kkma.pos(text))
lst= []
with open('ingredient2.txt', "r", encoding="utf-8") as file:
    for line in file:
        ingredient = line.strip()
        ingredient = ingredient.replace('적당량','')
        ingredient = ingredient.replace('쇠고기','소고기')
        if ingredient not in lst:
            lst.append(ingredient.replace(' ',''))
lst.sort()
with open('ingredient4.txt', 'w', encoding="utf-8") as file:
    for ingredient in lst:
        file.write(ingredient + '\n')