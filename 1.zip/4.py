from konlpy.tag import Kkma
kkma = Kkma()
text = '편 마늘'
print(kkma.pos(text))
lst= []
with open('ingredient2.txt', "r", encoding="utf-8") as file:
    for line in file:
        ingredient = line.strip()
        if ingredient:  # 빈 줄이 아닌 경우에만 추가
            ingredient = kkma.pos(ingredient)
            # print(ingredient)
        temp=''
        for i in ingredient:
            if i[1]!='SS' and  i[1]!='SW' and i[0] not in lst:

                temp+=str(i)
        lst.append(temp)
with open('ingredient3.txt', 'w', encoding="utf-8") as file:
    for ingredient in lst:
        file.write(ingredient + '\n')