def read_ingredients_from_file(file_path):
    ingredients_set = set()
    with open(file_path, "r", encoding="utf-8") as file:
        for line in file:
            ingredient = line.strip()
            if ingredient:  # 빈 줄이 아닌 경우에만 추가
                ingredients_set.add(ingredient)
    return ingredients_set

ingredients_set = read_ingredients_from_file("ingredients.txt")
ingredients_set = list(ingredients_set)
# print(ingredients_set)
ingredients_set.sort()

with open('ingredient2.txt', 'w', encoding="utf-8") as file:
    for ingredient in ingredients_set:
        file.write(ingredient + '\n')
